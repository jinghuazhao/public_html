#!/usr/local/bin/tcsh
rm -f drd4.out
/people/jzhao/packages/fbat/fbat <<seewhathappens
log drd4.out
log on
load ped drd4.dat
fbat
fbat -e
model d
fbat
model r
fbat
viewmarker DRD4
viewstat DRD4
log off
quit
seewhathappens
exit 0

# this was done on 2-OCT-2000
# JH Zhao
