options(echo=FALSE)
library(haplo.stats)

s2n <- function(snp)
{
   s <- strsplit(snp,"")
   l <- length(snp)
   a1 <- a2 <- vector("character",l)
   for(i in 1:l)
   {
      a1[i] <- s[[i]][1]
      a2[i] <- s[[i]][2]
   }
   list(a1=a1,a2=a2)
}

five <- read.delim("mc4r.out",as.is=TRUE)
attach(five)

cat("The third analysis\n")
a1a2 <- s2n(rs17782313)
snp1 <- allele.recode(a1a2$a1,a1a2$a2,miss.val=c("N",NA))
a1a2 <- s2n(rs12955983)
snp2 <- allele.recode(a1a2$a1,a1a2$a2,miss.val=c("N",NA))
a1a2 <- s2n(rs17700633)
snp3 <- allele.recode(a1a2$a1,a1a2$a2,miss.val=c("N",NA))
a1a2 <- s2n(rs718475)
snp4 <- allele.recode(a1a2$a1,a1a2$a2,miss.val=c("N",NA))
a1a2 <- s2n(rs9956279)
snp5 <- allele.recode(a1a2$a1,a1a2$a2,miss.val=c("N",NA))
snps <- cbind(snp1$a1,snp1$a2,snp2$a1,snp2$a2,snp3$a1,snp3$a2,snp4$a1,snp4$a2,snp5$a1,snp5$a2)

cat("Allele lables:\n")
locus.label <- c("rs17782313", "rs12955983", "rs17700633", "rs718475", "rs9956279")
cat(locus.label[1],snp1$allele.label,"\n")
cat(locus.label[2],snp2$allele.label,"\n")
cat(locus.label[3],snp3$allele.label,"\n")
cat(locus.label[4],snp4$allele.label,"\n")
cat(locus.label[5],snp5$allele.label,"\n")
cat("Haplotype analysis:\n")
haplo.score(zl10bmi,snps,x.adj=age,locus.label=locus.label,simulate=TRUE)

