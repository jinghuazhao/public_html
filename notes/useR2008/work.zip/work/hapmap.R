# 31-7-2008 MRC-Epid JHZ

library(snpMatrix)

baseurl <- "http://www.hapmap.org/genotypes/latest/rs_strand/non-redundant/";
CEU <- scan("CEU.lst",what="")

hapmap <- function(i=1)
{
  hapmap <- paste(baseurl,CEU[i],sep="")
  result <- read.HapMap.data(hapmap)
  sum <- summary(result$snp.data)
  invisible(list(snp.support=result$snp.support,snp.sum=sum[is.finite(sum$z.HWE),]))
}
for (i in 1:24)
{
  if (i==1) 
  {  hapmap1 <- hapmap(1)
     snp.support <- hapmap1$snp.support
     snp.sum <- hapmap1$snp.sum
  } else {
     hapmapi <- hapmap(i)
     snp.support <- rbind(snp.support,hapmapi$snp.support)
     snp.sum <- rbind(snp.sum,hapmapi$snp.sum)
  }
}
library(foreign)
setwd(".")
write.dta(cbind(row.names(snp.support),snp.support),"snp_support.dta")
write.dta(cbind(row.names(snp.sum),snp.sum),"snp_sum.dta")

q('no')
