#7-8-2008 MRC-Epid JHZ

library(foreign)
toplist <- read.dta("toplist.dta")
attach(toplist)

library(meta)
by(toplist,snp,function(x) metagen(b,se,data=x))

