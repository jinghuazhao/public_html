awk "END{print NR}" chr$1.dat > chr$1.no
awk -f gwas.lib -f l.awk no=$1 input=chr$1.no groups=$2 chr$1.dat
