library(foreign)
g4 <- read.dta("g4.dta")
g4pos <- read.dta("g4pos.dta")
library(SNPassoc)
snps <- setupSNP(g4, colSNPs=5:3961, sort = TRUE, info=g4pos)
library(qvalue)

## single stage analysis
stage1 <- (snps$stage==1)
snps1 <- snps[stage1,]
ans1 <- WGassociation(cc~b58cregion, data=snps1, model="log")
psnps1 <- attr(ans1,"pvalues")
x <- attr(ans1,"gen.info")
pdf("stage1.pdf")
plot(x$pos,-log(psnps1[,2]),ylim=c(0,10),xlab="position",ylab="-log(p)",type="p",pch=".")
title("Plot of single point p values at stage 1")
dev.off()
## joint analysis of SNPs at both stages
stage2 <- (snps$stage==2)
snps2sum <- apply(snps[stage2,-(1:4)],2,function(x) sum(is.na(x),na.rm=TRUE))
s1only <- (snps2sum==1978)
snps12 <- snps[,c(TRUE,TRUE,TRUE,TRUE,!s1only)]
snps12 <- setupSNP(snps12,colSNPs=5:dim(snps12)[2])
ans <- WGassociation(cc~stage+b58cregion, data=snps12, model="log")
x <- g4pos$pos[!s1only]
pdf("stage.pdf")
psnps <- attr(ans,"pvalues")
plot(x,-log(psnps[,2]),ylim=c(0,10),xlab="position",ylab="-log(p)",type="p",pch=".")
title("Plot of single point p values at stages 1/2")
qobj <- qvalue(psnps[,2])
qplot(qobj)
qwrite(qobj,filename="q.txt")
dev.off()

