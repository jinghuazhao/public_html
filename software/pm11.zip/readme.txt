A brief description of the files distributed is given as follows.

     readme.txt       this file
     eh.c             source code for EH
     eh.exe           EH executable (MSDOS)
     ehplus.c         source code for EHPLUS
     ehplush.c        source code with hash table
     ehplus.pas       Pascal code for EHPLUS
     ehplush.pas      Pascal code for EHPLUS with hash table
     ehplus.exe       EHPLUS executable (MSDOS)
     pm.c             source code for PM
     pm.exe           PM executable (MSDOS)
     pm.doc           PM documentation
     pmplus.c         source code for PMPLUS
     pmplus.exe       PMPLUS executable (MSDOS)
     Makefile.sun     A simple makefile for Sun
     Makefile.osf     A simple makefile for DEC Alpha

The first example in pm.doc uses the following files

     example.par      the parameter file
     example.dat      the data file
     case.dat         the case.dat as required by EH
     control.dat      the control.dat as required by EH
     eh.dat           the eh.dat as required by EH
     ehplus.dat       the ehplus.dat as required by EHPLUS

The second example in pm.doc uses the following files

     mm.par           the parameter file
     mm.dat           the data file

The HLA example in pm.doc uses the following files

     hla.par          the parameter file for HLA example
     hla.dat          the data file for HLA example
