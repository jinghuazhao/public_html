### Name: pathmix
### Title: Path analysis of pairs of relatives
### Aliases: pathmix
### Keywords: models

### ** Examples
## Not run: 
##D # test for ALMINI, check files ALMTEST.OUT and ALMTEST.PLX
##D pathmix(1)
##D # test for GEMINI, check files GEMTEST.OUT and GEMTEST.PLX
##D pathmix(2)
##D # path3a
##D pathmix(3, datfile="TEST.DAT", jobfile="test.jf")
##D # path3b
##D pathmix(4, datfile="TEST.DAT", jobfile="test.jf")
## End(Not run)


