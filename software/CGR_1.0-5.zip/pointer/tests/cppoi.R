library(pointer)
pointer("poidat","poijob","poipro","poiter")
