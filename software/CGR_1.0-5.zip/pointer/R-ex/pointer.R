### Name: pointer
### Title: Complex segregation analysis using pointers
### Aliases: pointer
### Keywords: models

### ** Examples
## Not run: 
##D # the documentation example
##D pointer("poidat","poijob","poipro","poiter")
##D file.show("poipro")
##D file.show("poiter")
## End(Not run)


