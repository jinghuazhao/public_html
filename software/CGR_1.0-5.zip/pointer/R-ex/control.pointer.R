### Name: control.pointer
### Title: Control routine for pointer
### Aliases: control.pointer
### Keywords: models

### ** Examples
## Not run: 
##D # Sibships with one or more unclassified parent and no pointer in one file,
##D # all other sibships in the other
##D control.pointer(mating.type="09,90,99",pointer.selection="0")
## End(Not run)


